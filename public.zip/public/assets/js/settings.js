'use strict';

const settings = {
    elements: {},
    pages: [],
    currentID: 123,
    currentPageName: '',
    maxLengthInPageHeader: 20,
    
}

export default settings;