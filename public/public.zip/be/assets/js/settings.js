'use strict';

const settings = {
    urlPages:'/data/pages.json',
    elements: {},
    pages:false,
    pagesStructured:{},
    activePageID:false,
    pageData:{},
    cutPage:false,
}

export default settings;